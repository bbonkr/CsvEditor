﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSVEditor.Helpers
{
    public class ManagedEncoding
    {
        public const string UTF8 = "UTF-8";
        public const string ANSI = "ANSI";
        public const string UNICODE = "UNICODE";
    }
}