﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CSVEditor.BackgroundWork
{
    public class Arguments : Dictionary<string, object>
    {
        public string Task { get; set; }
    }
}